// Punto.java (versión definitiva)
package es.uib.prgava.tema1.poo;

public record Punto(int x, int y) { }
