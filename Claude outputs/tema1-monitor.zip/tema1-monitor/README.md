# Tema 1 — Monitor de servicios de red (código de los ejemplos)

Proyecto Maven con **todos los listados** de `es/contenido/tema1.qmd`, generado a partir del
propio fichero Quarto (cada bloque `java` cuyo primer comentario es `// Nombre.java`).
Cuando un listado aparece varias veces en el texto (p. ej. `Monitor.java`, `Servicio.java`,
`SondaSimulada.java`), aquí está la **última** versión.

Paquetes:

- `es.uib.prgava.tema1.poo` — ejemplos breves de la sección 1.1
- `es.uib.prgava.tema1.genericos` — ejemplos breves de la sección 1.3
- `es.uib.prgava.tema1.monitor` — el ejemplo motivador (versión final de 1.2 y 1.3)
- `src/test/java/...` — las pruebas JUnit 5 de la sección 1.4 y el doble `SondaFalsa`

## Comprobar

```bash
mvn test                                   # compila y ejecuta las 21 pruebas
mvn -q exec:java -Dexec.mainClass=es.uib.prgava.tema1.monitor.Principal -Dexec.args=servicios.txt
mvn -q exec:java -Dexec.mainClass=es.uib.prgava.tema1.monitor.DemoInformes
```

(`exec:java` necesita el plugin `exec-maven-plugin`; si no lo tienes, ejecuta con
`java -cp target/classes es.uib.prgava.tema1.monitor.Principal servicios.txt`
después de `mvn compile`.)

## Comprobar las versiones del `pom.xml`

```bash
mvn versions:display-dependency-updates   # junit-jupiter
mvn versions:display-plugin-updates       # compiler, surefire
```

Si Maven no encuentra alguna versión, lo dirá al resolver dependencias en el primer `mvn test`.
Las versiones del `pom.xml` deben coincidir con las del listado de la sección 1.4 del tema.

## Flujo de GitHub Actions

El fichero `github-workflows-pruebas.yml` es el flujo de la sección 1.4; para activarlo en un
repositorio hay que moverlo a `.github/workflows/pruebas.yml` (la carpeta `.github` no se pudo
escribir desde la sesión remota).
